/*
 * File:   ecu1_sensor.c
 * Author: milan
 *
 * Created on 2 March, 2026, 12:23 PM
 */

#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"


static unsigned char gear_index = 0;

// gear array
char gear[][4] = {"OFF","ON ","G1 ","G2 ","G3 ","G4 ","G5 ","RE ","NU ","CO "};

uint16_t get_speed()
{
    uint16_t adc_val;
    uint16_t speed;
    adc_val = read_adc(SPEED_ADC_CHANNEL);
    speed = ((unsigned long)adc_val / 10.25);
    
    return speed;
}

unsigned char get_gear_pos()
{
    unsigned char key;

    key = read_digital_keypad(STATE_CHANGE);

    if(key == GEAR_UP)
    {
        if(gear_index < 8)   // till NU only
            gear_index++;
    }
    else if(key == GEAR_DOWN)
    {
        if(gear_index > 0)
            gear_index--;
    }
    else if(key == COLLISION)
    {
        gear_index = 9;     // CO
    }
   return gear_index;
}

