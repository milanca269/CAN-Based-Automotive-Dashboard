/*
 * File:   ecu1_main.c
 * Author: milan
 *
 * Created on 2 March, 2026, 12:22 PM
 */

/*
#include <xc.h>
#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
#include "uart.h"
#include "digital_keypad.h"
#include "clcd.h"


#define _XTAL_FREQ 20000000

extern char gear[][4];

void main(void)
{
    uint16_t speed;
    unsigned char gear_pos;
    unsigned char speed_tens, speed_units;

    init_adc();
    init_digital_keypad();
    init_uart();

    uint16_t prev_speed = 255;
unsigned char prev_gear = 255;

puts("\r\nDashboard Started...\r\n");
while(1)
{
    speed = get_speed();
    gear_pos = get_gear_pos();

    if((speed != prev_speed) || (gear_pos != prev_gear))
    {
        puts("\r\nSpeed: ");
        putch((speed/10) + '0');
        putch((speed%10) + '0');

        puts("  Gear: ");
        puts(gear[gear_pos]);

        prev_speed = speed;
        prev_gear = gear_pos;
    }
} //to prevent same speed gear printing  
}

*/

#include <xc.h>
#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
#include "uart.h"
#include "digital_keypad.h"

#define _XTAL_FREQ 20000000

extern char gear[][4];

void main(void)
{
    uint16_t speed;
    unsigned char gear_pos;
    
    uint8_t tx_speed[1];//buffer for speed message
    uint8_t tx_gear[1];// buffer for gear message
    uint8_t rx_data[8];    // receive buffer
    

    uint8_t len;
    uint16_t msg_id;

    init_adc();
    init_digital_keypad();
//    init_uart();
    init_can();

    puts("\r\nCAN Loopback Dashboard Started...\r\n");

    while(1)
    {
        //get speed n gear
        speed = get_speed();
       __delay_ms(50);

        //TRANSMIT SPEED 
        tx_speed[0] = (uint8_t)speed;
        can_transmit(SPEED_MSG_ID, tx_speed, 1);
        

        /* //RECEIVE SPEED
        can_receive(&msg_id, rx_data, &len);
        
            puts("\r\nSpeed: ");
            putch((rx_data[0] / 10) + '0');
            putch((rx_data[0] % 10) + '0');
        */
        
        //TRANSMIT GEAR 
        gear_pos = get_gear_pos();
         __delay_ms(50);
        tx_gear[0] = gear_pos;
        can_transmit(GEAR_MSG_ID, tx_gear, 1);
       

        // RECEIVE GEAR 
       /* can_receive(&msg_id, rx_data, &len);
       
           puts("  Gear: ");
          puts(gear[rx_data[0]]);
        */
        
       // __delay_ms(200);
    }
}


 
/*
#include <xc.h>//only trasmitter
#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
#include "digital_keypad.h"

#define _XTAL_FREQ 20000000

void main(void)
{
    uint16_t speed;
    unsigned char gear_pos;

    uint8_t tx_speed[1];
    uint8_t tx_gear[1];

    init_adc();
    init_digital_keypad();
    init_can();

    while(1)
    {
        speed = get_speed();
        gear_pos = get_gear_pos();

        // Send Speed 
        tx_speed[0] = speed;
        can_transmit(SPEED_MSG_ID, tx_speed, 1);

        __delay_ms(100);

        // Send Gear 
        tx_gear[0] = gear_pos;
        can_transmit(GEAR_MSG_ID, tx_gear, 1);

        __delay_ms(100);
    }
}
*/
