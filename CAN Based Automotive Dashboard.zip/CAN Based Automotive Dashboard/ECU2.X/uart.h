/* 
 * File:   uart.h
 * Author: milan
 *
 * Created on 9 March, 2026, 11:58 AM
 */

#ifndef SCI_H
#define SCI_H

#define RX_PIN					TRISC7
#define TX_PIN					TRISC6

void init_uart(void);
void putch(unsigned char byte);
void puts(unsigned char *data);
unsigned char getch(void);
unsigned char getch_with_timeout(unsigned short max_time);
unsigned char getche(void);

#endif
