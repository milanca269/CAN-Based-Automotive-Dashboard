/*
 * File:   uart.c
 * Author: milan
 *
 * Created on 9 March, 2026, 11:51 AM
 */


#include <xc.h>
#include "uart.h"

void init_uart(void)
{  
    TRISC6=0;
    TRISC7=1;
    
   // TXSTA  control register CONFIGURATION
   TX9=1; //parity excluded
   TXEN=1;//transmit enable bit
   SYNC=0; //asynchronous
   SENDB=0; //disable break character
   BRGH=1; //high speed
   
   
   
   //RCSTA (RECEPTION) control  register CONFIGURATION
   SPEN = 1;//serial port enabled
   RX9=0;//selecte 8 bit reception
   CREN=1;//enables receiver
   
   
   //BAUDCON  cobtrol register CONFIGURATION
   
   ABDOVF=0;//baud rate measurement disabled or completed
   BRG16=0;//8 bit baud rate
   WUE=0;//disable wakeup enable
   ABDEN=0;//auto baud rate detect disable
   SPBRG=129;//setting the baud rate as 9600
   TXIF=0;
   RCIF=0;
}

void putch(unsigned char data)
{
    while(!TXIF);
    TXREG =data;
}

unsigned char getchar(void)
{
    while(!RCIF);
    
    return RCREG;
}

void puts(unsigned char* data)
{
    while(*data!='\0')
    {
        putch(*data);
        data++;
    }
    
}