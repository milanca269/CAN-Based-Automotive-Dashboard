/*
 * File:   ssd_display.c
 * Author: milan
 *
 * Created on 10 March, 2026, 2:25 PM
 */


#include <xc.h>
#include "ssd_display.h"

void init_ssd(void)
{
    //setting the control pins(port a) as output
    CONTROL_PORT_DDR = CONTROL_PORT_DDR & 0XF0;
    
    //setting the DATA pins(port D) as output
    DATA_PORT_DDR = 0X00;
    
    
    //INITIALISING control pins(port a) as output
    CONTROL_PORT = CONTROL_PORT & 0XF0;
}   
    void display(unsigned char * SSD)
    {
        for(int i=0;i<4;i++)
        {
            DATA_PORT=SSD[i];
            CONTROL_PORT=(CONTROL_PORT & 0XF0) | (1<<i);
            for(int wait =1000;wait--;);
        }
    }
