/*
 * File:   main.c
 * Author: milan
 *
 * Created on 6 March, 2026, 2:57 PM
 */


/*
#include<xc.h>
#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
#include "ssd_display.h"

#define _XTAL_FREQ 20000000

//ssd
unsigned char seg_code[]={0xE7,0X21,0XCB,0X6B,0X2D,0X6E,0XEE,0X23,0XEF,0X6F};


int main()
{
    uint16_t rpm;
    unsigned char ssd[4];
    
    init_adc();
    init_digital_keypad();
    init_ssd();
    
        TRISC |= 0x0F;   // RC0-RC3 as input
        TRISB = 0x00;    // LEDs output
        PORTB = 0x00;

    while(1)
    {
        //READ RPM 
        rpm = get_rpm();

        // DIGITS on ssd
        ssd[0] = seg_code[(rpm / 1000) % 10];
        ssd[1] = seg_code[(rpm / 100) % 10];
        ssd[2] = seg_code[(rpm / 10) % 10];
        ssd[3] = seg_code[rpm % 10];

        // DISPLAY digits ON SSD 
        display(ssd);

        // INDICATOR PROCESS 
        process_indicator();

        //BLINK CONTROL
        static unsigned int delay = 0;

            if(delay++ == 100)
            {
                delay = 0;
                led_state = !led_state;
            }
    }
}
 */

#include <xc.h>
#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "uart.h"
#include "msg_id.h"
#include "ssd_display.h"

#define _XTAL_FREQ 20000000

unsigned char seg_code[] = {0xE7, 0X21, 0XCB, 0X6B, 0X2D, 0X6E, 0XEE, 0X23, 0XEF, 0X6F};

int main() {
    uint16_t rpm;
    //unsigned char ssd[4];

    uint8_t tx_rpm[2];
    uint8_t tx_ind[1];

    uint8_t rx_data[8];
    uint8_t len;
    uint16_t msg_id;
    uint8_t rx_ind;

    init_adc();
    init_digital_keypad();
     init_uart();
    init_can();
   // init_ssd();
       TRISB = 0x08;  
       TRISC |= 0x0F;

    while (1)
    {
       rpm = get_rpm();

       tx_rpm[0] = rpm >> 8;
       tx_rpm[1] = rpm & 0xFF; 

        can_transmit(RPM_MSG_ID, tx_rpm, 2);
       __delay_ms(80);

         //CAN RECEIVE rpm
       
      /* can_receive(&msg_id, rx_data, &len);


        if (msg_id == RPM_MSG_ID) {
            uint16_t received_rpm = 0;
            received_rpm = ((uint16_t) rx_data[0] << 8) | rx_data[1];

            puts("RPM: ");

            putch((received_rpm / 1000) % 10 + '0');
            putch((received_rpm / 100) % 10 + '0');
            putch((received_rpm / 10) % 10 + '0');
            putch(received_rpm % 10 + '0');

            //puts("\n");

            
        }
*/

        process_indicator();
        //  CAN TRANSMIT INDICATOR 
        
        can_transmit(INDICATOR_MSG_ID, &cur_ind_status, 1);
        //  CAN RECEIVE  indicator
        __delay_ms(80);

        /*can_receive(&msg_id, &rx_ind, &len);
               rx_data[len] = '\0';


       if (msg_id == INDICATOR_MSG_ID) {
            puts("Indicator: ");

            if (rx_ind == 0)
                puts("OFF");
            else if (rx_ind == 1)
                puts("LEFT");
            else if (rx_ind == 2)
                puts("RIGHT");
            else if (rx_ind == 3)
                puts("HAZARD");
            //else
            //puts("HArd coded value");
            puts("\r\n");

           //BLINK CONTROL
        static unsigned int delay = 0;

            if(delay++ == 5)
            {
                delay = 0;
                led_state = !led_state;
            }
        }*/
    }
}


    


/*
#include <xc.h>
#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "ssd_display.h"

#define _XTAL_FREQ 20000000

unsigned char seg_code[]={0xE7,0X21,0XCB,0X6B,0X2D,0X6E,0XEE,0X23,0XEF,0X6F};

int main()
{
    uint16_t rpm;
    unsigned char ssd[4];

    uint8_t tx_rpm[2];
    uint8_t tx_ind[1];

    init_adc();
    init_digital_keypad();
    init_ssd();
    init_can();

    TRISC |= 0x0F;
    TRISB = 0x00;
    PORTB = 0x00;

    while(1)
    {
        rpm = get_rpm();
        process_indicator();

        // LED blinking
        static unsigned int delay=0;
        if(delay++==100)
        {
            delay=0;
            led_state=!led_state;
        }

        // SSD display
        ssd[0] = seg_code[(rpm/1000)%10];
        ssd[1] = seg_code[(rpm/100)%10];
        ssd[2] = seg_code[(rpm/10)%10];
        ssd[3] = seg_code[rpm%10];

        display(ssd);

        // SEND RPM
        tx_rpm[0] = rpm >> 8;
        tx_rpm[1] = rpm & 0xFF;

        can_transmit(RPM_MSG_ID, tx_rpm, 2);

        // SEND INDICATOR
        tx_ind[0] = cur_ind_status;

        can_transmit(INDICATOR_MSG_ID, tx_ind, 1);

        __delay_ms(50);
    }
}
 */

