/* 
 * File:   ssd_display.h
 * Author: milan
 *
 * Created on 10 March, 2026, 2:25 PM
 */

#ifndef SSD_DISPLAY_H
#define SSD_DISPLAY_H



//SSD PORT DEFINITIONS 

/* Control lines connected to PORTA */
#define CONTROL_PORT        PORTA
#define CONTROL_PORT_DDR    TRISA

//Segment data lines connected to PORTD 
#define DATA_PORT           PORTD
#define DATA_PORT_DDR       TRISD

//FUNCTION PROTOTYPES 

void init_ssd(void);
void display(unsigned char *SSD);

#endif  /* SSD_DISPLAY_H */

