/*
 * File:   ecu2_sensor.c
 * Author: milan
 *
 * Created on 9 March, 2026, 11:50 AM
 */


#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"

volatile IndicatorStatus cur_ind_status = e_ind_off;
volatile unsigned char led_state = 0;

//RPM FUNCTION 
//ADC 0to 1023 to 0 to 6000 
uint16_t get_rpm(void)
{
    uint16_t adc_val;
    uint16_t rpm;

    adc_val = read_adc(RPM_ADC_CHANNEL);

    rpm = ((unsigned long)adc_val * 6000) / 1023;

    return rpm;
}

//INDICATOR FUNCTION 
IndicatorStatus process_indicator(void)
{
    // Active LOW switches
    if(RC0 == 0)          // SWITCH1 -> LEFT
    {
        cur_ind_status = e_ind_left;
    }
    else if(RC1 == 0)     // SWITCH2 -> RIGHT
    {
        cur_ind_status = e_ind_right;
    }
    else if(RC2 == 0)     // SWITCH3 -> HAZARD
    {
        cur_ind_status = e_ind_hazard;
    }
    else if(RC3 == 0)     // SWITCH4 -> OFF
    {
        cur_ind_status = e_ind_off;
    }

    // LED CONTROL 

    if(cur_ind_status == e_ind_left)
    {
        if(led_state)
            LEFT_IND_ON();
        else
            LEFT_IND_OFF();

        RIGHT_IND_OFF();
    }
    else if(cur_ind_status == e_ind_right)
    {
        if(led_state)
            RIGHT_IND_ON();
        else
            RIGHT_IND_OFF();

        LEFT_IND_OFF();
    }
    else if(cur_ind_status == e_ind_hazard)
    {
        if(led_state)
        {
            LEFT_IND_ON();
            RIGHT_IND_ON();
        }
        else
        {
            LEFT_IND_OFF();
            RIGHT_IND_OFF();
        }
    }
    else
    {
        LEFT_IND_OFF();
        RIGHT_IND_OFF();
    }

    return cur_ind_status;
}
uint16_t get_engine_temp()
{
    //Implement the engine temperature function
}


