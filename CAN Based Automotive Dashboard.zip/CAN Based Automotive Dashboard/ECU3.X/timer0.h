/* 
 * File:   timer0.h
 * Author: milan
 *
 * Created on 23 March, 2026, 2:20 PM
 */

#ifndef TIMER0_H
#define	TIMER0_H

void init_timer0(void);

#endif	/* TIMER0_H */

