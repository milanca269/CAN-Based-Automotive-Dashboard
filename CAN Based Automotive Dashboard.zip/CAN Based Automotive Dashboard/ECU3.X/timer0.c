/*
 * File:   timer0.c
 * Author: milan
 *
 * Created on 23 March, 2026, 2:20 PM
 */


#include <xc.h>
#include "timer0.h"
#include "message_handler.h"
unsigned char blink = 0;
unsigned int timer = 0;

void init_timer0(void) 
{

    T08BIT = 1;
    T0CS = 0;
    PSA = 0;
    T0PS2 = 1;
    T0PS1 = 1; //pre-scaler 1:256
    T0PS0 = 1;
    TMR0 = 6;
    TMR0IF = 0;
    TMR0IE = 1;
    TMR0ON = 1;

    GIE = 1;
    PEIE = 1;
}


void __interrupt() isr(void) 
{
    if (TMR0IF) 
    {
        TMR0IF = 0;
        TMR0 = TMR0 + 6;
        timer++; // 40 * 12.8 ms = 512ms
        if (timer >= 40) 
        {
            timer = 0;
            blink = !blink;
        }
    }
}

