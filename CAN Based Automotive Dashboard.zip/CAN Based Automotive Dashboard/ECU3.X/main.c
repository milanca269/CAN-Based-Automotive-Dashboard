/*
 * File:   main.c
 * Author: milan
 *
 * Created on 10 March, 2026, 12:15 PM
 */


#include <xc.h>
#include <stdint.h>
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "message_handler.h"
#include "timer0.h"

extern unsigned char blink;
static void init_leds() 
{
    TRISB = 0x08; // Set RB2 as output, RB3 as input, remaining as output
    PORTB = 0x00;
}

static void init_config(void) 
{
    // Initialize CLCD and CANBUS
    init_clcd();
    init_can();
    init_leds();
    init_timer0();
    
    clcd_print("SP",LINE1(0));
    clcd_print("G",LINE1(4));
    clcd_print("RPM",LINE1(7));
    clcd_print("IND",LINE1(12));
}

void main(void) 
{
    // Initialize peripherals
    init_config();

    /* ECU1 main loop */
    while (1) 
    {
        // Read CAN Bus data and handle it
        process_canbus_data();
        if (status == e_ind_left) 
            {
                if (blink) 
                {
                    LEFT_IND_ON();
                } 
                else 
                {
                    LEFT_IND_OFF();
                }
                RIGHT_IND_OFF();
            } 
            else if (status == e_ind_right) 
            {
                if (blink) 
                {
                    RIGHT_IND_ON();
                } 
                else 
                {
                    RIGHT_IND_OFF();
                }

                LEFT_IND_OFF();
            } 
            else if (status == e_ind_hazard) 
            {
                if (blink) 
                {
                    LEFT_IND_ON();
                    RIGHT_IND_ON();
                } 
                else
                {
                    LEFT_IND_OFF();
                    RIGHT_IND_OFF();
                }

            } 
            else 
            {
                LEFT_IND_OFF();
                RIGHT_IND_OFF();
            }
        
    }
    return;
}



